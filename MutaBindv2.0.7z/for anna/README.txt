Files:
SkempiS_WithModelFeatures.txt	Training set used for developing MutaBindS.
SkempiM_WithModelFeatures.txt	Training set used for developing MutaBindM.

	Terms in the files:
	PDB id: The PDB entry of the complex.
	Partner1: Protein chains constituting one of the interaction partner. 
	Partner2: Protein chains constituting the other one of the interaction partner. 
	Mutated Chain: Protein chain with mutation.
	Mutation(MutaBindS.txt): The first character is one letter amino acid code for the wild-type residue, the second to penultimate characters indicate residue number, and the final character indicates the mutant amino acid.
	Mutation(MutaBindM.txt): The first character is one letter amino acid code for the wild-type residue, the second character is the mutated chain, the third to penultimate characters indicate residue number, and the final character indicates the mutant amino acid.
	DDGexp: Experimental changes of binding affinity upon mutations (in kcal/mol).
	label_dataset: 'forward' means the dataset SkempiS.F/SkempiM.F(wt->mut), 'reverse' means the dataset SkempiS.R/SkempiM.R(mut->wt).



BuildModel.R 	the script for building model .








